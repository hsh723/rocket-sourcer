<?php
// Silence is golden. 